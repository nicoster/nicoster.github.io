find . -name '*.xcodeproj'|xargs svn ps svn:ignore '
*.pbxuser
*.mode1v3
'
find . -name 'build'|awk '{gsub(/\/build/, "", $0);print}'|xargs svn ps svn:ignore '
build
'

